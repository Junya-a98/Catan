import os
import random
import pygame

pygame.init()
WIDTH, HEIGHT = 960, 640
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
pygame.display.set_caption("d12 demo")

ASSET_DIR = os.path.dirname(__file__)
idle = pygame.image.load(os.path.join(ASSET_DIR, "d12_idle.png")).convert_alpha()
face_images = [
    pygame.image.load(os.path.join(ASSET_DIR, "faces", f"d12_face_{i:02d}.png")).convert_alpha()
    for i in range(1, 13)
]
roll_frames = [
    pygame.image.load(os.path.join(ASSET_DIR, "roll", f"d12_roll_{i:02d}.png")).convert_alpha()
    for i in range(24)
]
font = pygame.font.SysFont(None, 36)

state = "idle"
result = 1
frame = 0
roll_start = 0
ROLL_TIME_MS = 900

running = True
while running:
    dt = clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            state = "rolling"
            roll_start = pygame.time.get_ticks()
            result = random.randint(1, 12)

    now = pygame.time.get_ticks()
    if state == "rolling":
        elapsed = now - roll_start
        frame = int((elapsed / 50) % len(roll_frames))
        image = roll_frames[frame]
        if elapsed >= ROLL_TIME_MS:
            state = "result"
    elif state == "result":
        image = face_images[result - 1]
    else:
        image = idle

    screen.fill((26, 29, 36))
    rect = image.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20))
    screen.blit(image, rect)

    msg = "SPACEでロール" if state != "result" else f"結果: {result}  /  SPACEで再ロール"
    txt = font.render(msg, True, (235, 240, 250))
    txt_rect = txt.get_rect(center=(WIDTH // 2, HEIGHT - 60))
    screen.blit(txt, txt_rect)
    pygame.display.flip()

pygame.quit()
