d12 Pygame Assets
=================

内容:
- d12_idle.png: 待機用
- faces/d12_face_01.png 〜 d12_face_12.png: 結果表示用
- roll/d12_roll_00.png 〜 d12_roll_23.png: ロール演出用
- d12_faces_sheet.png: 結果表示用スプライトシート
- d12_roll_sheet.png: ロール演出用スプライトシート
- d12_shadow.png: 影だけの素材
- example_pygame_usage.py: Pygame読み込みサンプル

推奨:
- 結果表示は faces/ を使う
- 振る演出は roll/ または d12_roll_sheet.png を使う
- 1フレームサイズは 256x256 PNG です
